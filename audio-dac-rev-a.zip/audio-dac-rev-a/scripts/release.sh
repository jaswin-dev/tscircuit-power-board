#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

npm run typecheck
npm run build
"${KICAD_PYTHON:-/usr/bin/python3}" scripts/export-pcb.py

mkdir -p build/gerbers
pcb=build/audio-dac.kicad_pcb
kicad-cli pcb drc "$pcb" --all-track-errors --severity-all --exit-code-violations -o build/drc.txt
kicad-cli pcb export gerbers "$pcb" --output build/gerbers/ \
    --layers F.Cu,In1.Cu,In2.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,B.SilkS,F.Paste,Edge.Cuts \
    --subtract-soldermask
kicad-cli pcb export drill "$pcb" --format excellon --excellon-units mm \
    --excellon-separate-th --output build/gerbers/
rm -f build/JLCPCB-Gerbers.zip
zip -q -j build/JLCPCB-Gerbers.zip build/gerbers/audio-dac-*.g* build/gerbers/audio-dac-*.drl
kicad-cli pcb render "$pcb" --output build/board-preview.png --width 1400 --height 980 \
    --side top --rotate '26,0,15' --zoom 1.12 --background transparent
