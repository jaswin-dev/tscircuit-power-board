import { mkdirSync, writeFileSync } from "node:fs"
import { Circuit } from "tscircuit"
import { convertCircuitJsonToPcbSvg, convertCircuitJsonToSchematicSvg } from "circuit-to-svg"
import AudioDac from "../src/audio-dac.circuit.js"
import { board, parts } from "../src/design.js"
import catalog from "../src/jlcpcb-parts.json" with { type: "json" }
import { planes, routes } from "../src/routing.js"

const circuit = new Circuit()
circuit.add(<AudioDac />)
await circuit.renderUntilSettled()
const json = circuit.getCircuitJson()
const errors = json.filter((element) => element.type.endsWith("_error"))
if (errors.length) throw new Error(JSON.stringify(errors, null, 2))
const renderedRoutes = json.filter((element) => element.type === "pcb_trace")
if (renderedRoutes.length !== routes.length) throw new Error("One or more manual routes failed to render")
const sourceNets = json.filter((element) => element.type === "source_net")
const sourceTraces = json.filter((element) => element.type === "source_trace")
const routedNets = Object.fromEntries(renderedRoutes.map((trace) => {
  const routeIndex = Number(trace.source_trace_id?.replace(/^manual_/, ""))
  const net = routes[routeIndex]?.net
  const netId = sourceNets.find((source) => source.name === net)?.source_net_id
  const sourceTrace = sourceTraces.find((source) => netId && source.connected_source_net_ids?.includes(netId))
  if (!sourceTrace) throw new Error(`Missing source net for ${trace.pcb_trace_id}`)
  trace.source_trace_id = sourceTrace.source_trace_id
  return [trace.pcb_trace_id, net]
}))

// Named endpoint stubs keep repeated rails and crossing nets unambiguous.
const netByPort = new Map(sourceTraces.flatMap((trace) =>
  (trace.connected_source_port_ids ?? []).map((portId) => [portId, trace] as const)
))
const labeledSchematic: typeof json = json.filter((element) =>
  element.type !== "schematic_trace" && element.type !== "schematic_net_label" &&
  (element.type !== "schematic_text" || Boolean(element.schematic_component_id))
)
for (const port of json.filter((element) => element.type === "schematic_port")) {
  const trace = netByPort.get(port.source_port_id)
  const net = sourceNets.find((source) => source.source_net_id === trace?.connected_source_net_ids?.[0])
  if (!trace || !net) throw new Error(`Missing schematic net for ${port.source_port_id}`)
  const left = port.facing_direction === "left"
  const end = { x: port.center.x + (left ? -0.28 : 0.28), y: port.center.y }
  const id = port.schematic_port_id
  labeledSchematic.push(
    {
      type: "schematic_trace", schematic_trace_id: `stub_${id}`, source_trace_id: trace.source_trace_id,
      edges: [{ from: port.center, to: end }], junctions: [],
    },
    {
      type: "schematic_text", schematic_text_id: `label_${id}`, text: net.name,
      anchor: left ? "right" : "left", rotation: 0,
      position: { x: end.x + (left ? -0.04 : 0.04), y: end.y }, font_size: 0.145, color: "#006464",
    },
  )
}
mkdirSync("build", { recursive: true })
writeFileSync("build/circuit.json", JSON.stringify(labeledSchematic, null, 2) + "\n")
// The renderer and Circuit temporarily use different circuit-json revisions.
const previewJson = labeledSchematic as Parameters<typeof convertCircuitJsonToPcbSvg>[0]
writeFileSync("build/pcb.svg", convertCircuitJsonToPcbSvg(previewJson))
writeFileSync("build/schematic.svg",
  convertCircuitJsonToSchematicSvg(previewJson).replaceAll('fill="transparent"', 'fill="none"'))
writeFileSync("build/manufacture.json", JSON.stringify({
  board, parts, catalog, planes, routedNets,
}, null, 2) + "\n")
