"""Turn the rendered tscircuit PCB and named plane definitions into a KiCad PCB."""
import csv
import json
import shutil
from collections import defaultdict
from pathlib import Path

import pcbnew as p

BUILD = Path("build")
circuit = json.loads((BUILD / "circuit.json").read_text())
design = json.loads((BUILD / "manufacture.json").read_text())
elements = defaultdict(list)
for element in circuit:
    elements[element["type"]].append(element)

pcb = p.BOARD()
pcb.SetCopperLayerCount(design["board"]["layers"])
mm = p.FromMM
shutil.copytree("models", BUILD / "models", dirs_exist_ok=True)
library = BUILD / "AudioDAC.pretty"
plugin = p.PCB_IO_KICAD_SEXPR()
if not library.exists():
    plugin.FootprintLibCreate(str(library))
(BUILD / "fp-lib-table").write_text(
    '(fp_lib_table (version 7)\n'
    '  (lib (name "AudioDAC") (type "KiCad") (uri "${KIPRJMOD}/AudioDAC.pretty") (options "") (descr "Imported JLCPCB footprints"))\n)\n'
)
saved_footprints = set()


def xy(x, y):
    return p.VECTOR2I(mm(21 + x), mm(14 - y))


def vector(x, y):
    return p.VECTOR2I(mm(x), mm(y))


def point(element):
    return xy(element["x"], element["y"])


nets = {}
for source in elements["source_net"]:
    name = source["name"]
    net = p.NETINFO_ITEM(pcb, name)
    pcb.Add(net)
    nets[name] = net

source_parts = {part["source_component_id"]: part["name"] for part in elements["source_component"]}
components = {source_parts[part["source_component_id"]]: part for part in elements["pcb_component"]}
source_nets = {net["source_net_id"]: net["name"] for net in elements["source_net"]}
net_by_port = {
    port_id: source_nets[trace["connected_source_net_ids"][0]]
    for trace in elements["source_trace"]
    for port_id in trace["connected_source_port_ids"]
}
source_port_ids = {port["pcb_port_id"]: port["source_port_id"] for port in elements["pcb_port"]}
pad_shapes = {"rect": p.PAD_SHAPE_RECT, "oval": p.PAD_SHAPE_OVAL, "circle": p.PAD_SHAPE_CIRCLE}

refs = {
    "U1": (0, -3.95),
    "J1": (13.7, 5.08), "J2": (-13.7, 0),
    "C1": (-7.95, 4.9), "C2": (-8.2, 6.8), "C3": (-7.45, 2.43),
    "C4": (-8.3, 1.32), "C5": (-3.45, -5.8), "C6": (-8.95, -6.75),
    "C7": (5.1, 5.78), "C8": (8.45, 5.85), "C9": (5.4, 0.82),
    "C10": (-12, 1.02), "C11": (-12, -6.45),
    "R1": (-8.88, -2.58), "R2": (-8.88, -4.76),
}


def add_shape(container, layer, kind, start, end, width):
    shape = p.PCB_SHAPE(container)
    shape.SetShape(kind)
    shape.SetLayer(layer)
    shape.SetStart(start)
    shape.SetEnd(end)
    shape.SetWidth(mm(width))
    container.Add(shape)


models = {
    "C107671": ("TSSOP-20", 0, -90),
    "C50951": ("Header-1x05", -5.08, -90),
    "C49257": ("Header-1x03", -2.54, -90),
    "C14663": ("C-0603", 0, 0),
    "C107043": ("C-0603", 0, 0),
    "C1713": ("C-0805", 0, 0),
    "C28234": ("C-0805", 0, 0),
    "C114669": ("R-0603", 0, 0),
}

width = design["board"]["width"]
height = design["board"]["height"]
add_shape(pcb, p.Edge_Cuts, p.SHAPE_T_RECT,
          xy(-width / 2, height / 2), xy(width / 2, -height / 2), 0.05)

for part in design["parts"]:
    ref = part["ref"]
    footprint = p.FOOTPRINT(pcb)
    footprint.SetReference(ref)
    footprint.SetValue(part["value"])
    footprint.SetFPIDAsString("AudioDAC:" + part["code"])
    footprint.SetLayer(p.F_Cu)
    footprint.SetAttributes(p.FP_THROUGH_HOLE if ref.startswith("J") else p.FP_SMD)
    footprint.Value().SetVisible(False)
    footprint.SetAllowMissingCourtyard(True)
    pcb.Add(footprint)
    component = components[ref]
    rotation = part["rotation"]
    footprint.SetPosition(point(component["footprint_origin"]))
    footprint.SetOrientationDegrees(rotation)

    pcb_pads = {}
    for pad in elements["pcb_smtpad"] + elements["pcb_plated_hole"]:
        if pad["pcb_component_id"] == component["pcb_component_id"]:
            pcb_pads[next(int(hint[3:]) for hint in pad["port_hints"] if hint.startswith("pin") and hint[3:].isdigit())] = pad
    catalog = design["catalog"][part["code"]]
    assert len(pcb_pads) == len(catalog["pads"]), (ref, pcb_pads)
    for definition in catalog["pads"]:
        pin = definition["pin"]
        rendered = pcb_pads[pin]
        pad = p.PAD(footprint)
        pad.SetPosition(point(rendered))
        pad.SetNumber(str(pin))
        pad.SetShape(pad_shapes[definition["shape"]])
        pad.SetSize(vector(definition["width"], definition["height"]))
        pad.SetOrientationDegrees(rotation)
        net_name = net_by_port[source_port_ids[rendered["pcb_port_id"]]]
        assert net_name == part["pins"][pin - 1], (ref, pin, net_name)
        pad.SetNet(nets[net_name])
        if definition["drill"]:
            pad.SetAttribute(p.PAD_ATTRIB_PTH)
            pad.SetLayerSet(p.PAD.PTHMask())
            pad.SetDrillSize(vector(definition["drill"], definition["drill"]))
        else:
            pad.SetAttribute(p.PAD_ATTRIB_SMD)
            pad.SetLayerSet(p.PAD.SMDMask())
        footprint.Add(pad)

    if ref.startswith("J"):
        x, y = part["at"]
        half_length = len(part["pins"]) * 1.27
        add_shape(footprint, p.F_SilkS, p.SHAPE_T_RECT,
                  xy(x - 1.30, y + half_length), xy(x + 1.30, y - half_length), 0.15)

    reference = footprint.Reference()
    reference.SetLayer(p.F_SilkS)
    reference.SetVisible(True)
    reference.SetKeepUpright(True)
    reference.SetTextAngle(p.EDA_ANGLE(0, p.DEGREES_T))
    reference.SetTextSize(vector(0.8, 0.8))
    reference.SetTextThickness(mm(0.12))
    reference.SetPosition(xy(*refs[ref]))

    model_name, offset, model_rotation = models[part["code"]]
    model = p.FP_3DMODEL()
    model.m_Filename = "${KIPRJMOD}/models/" + model_name + ".wrl"
    model.m_Offset = p.VECTOR3D(offset, 0, 0)
    model.m_Rotation = p.VECTOR3D(0, 0, model_rotation)
    footprint.Add3DModel(model)
    if part["code"] not in saved_footprints:
        original = footprint.Duplicate()
        original.SetOrientationDegrees(0)
        original.SetPosition(vector(0, 0))
        plugin.FootprintSave(str(library), original)
        saved_footprints.add(part["code"])

for index, hole in enumerate(elements["pcb_hole"], 1):
    footprint = p.FOOTPRINT(pcb)
    footprint.SetReference(f"H{index}")
    footprint.SetValue("3.2mm NPTH")
    footprint.SetLayer(p.F_Cu)
    footprint.SetAttributes(p.FP_BOARD_ONLY | p.FP_EXCLUDE_FROM_BOM | p.FP_EXCLUDE_FROM_POS_FILES)
    footprint.Reference().SetVisible(False)
    footprint.Value().SetVisible(False)
    footprint.SetAllowMissingCourtyard(True)
    footprint.SetPosition(point(hole))
    pcb.Add(footprint)
    pad = p.PAD(footprint)
    pad.SetPosition(point(hole))
    pad.SetAttribute(p.PAD_ATTRIB_NPTH)
    pad.SetLayerSet(p.PAD.UnplatedHoleMask())
    pad.SetShape(p.PAD_SHAPE_CIRCLE)
    drill_size = vector(hole["hole_diameter"], hole["hole_diameter"])
    pad.SetSize(drill_size)
    pad.SetDrillSize(drill_size)
    footprint.Add(pad)

assert len(elements["pcb_trace"]) == len(design["routedNets"])
for trace in elements["pcb_trace"]:
    net = nets[design["routedNets"][trace["pcb_trace_id"]]]
    wire = [entry for entry in trace["route"] if entry["route_type"] == "wire"]
    for start, end in zip(wire, wire[1:]):
        if point(start) == point(end):
            continue
        track = p.PCB_TRACK(pcb)
        track.SetStart(point(start))
        track.SetEnd(point(end))
        track.SetLayer(p.F_Cu)
        track.SetWidth(mm(start["width"]))
        track.SetNet(net)
        pcb.Add(track)
    for entry in trace["route"]:
        if entry["route_type"] == "via":
            via = p.PCB_VIA(pcb)
            via.SetPosition(point(entry))
            via.SetWidth(p.F_Cu, mm(entry["outer_diameter"]))
            via.SetDrill(mm(entry["hole_diameter"]))
            via.SetViaType(p.VIATYPE_THROUGH)
            via.SetLayerPair(p.F_Cu, p.B_Cu)
            via.SetNet(net)
            via.SetFrontTentingMode(p.TENTING_MODE_TENTED)
            via.SetBackTentingMode(p.TENTING_MODE_TENTED)
            pcb.Add(via)

for label in elements["pcb_silkscreen_text"]:
    text = p.PCB_TEXT(pcb)
    text.SetText(label["text"])
    back = label["layer"] == "bottom"
    text.SetLayer(p.B_SilkS if back else p.F_SilkS)
    text.SetMirrored(back)
    text.SetPosition(point(label["anchor_position"]))
    size = label["font_size"]
    text.SetTextSize(vector(size, size))
    text.SetTextThickness(mm(0.15 if size >= 0.9 else 0.12))
    pcb.Add(text)

add_shape(pcb, p.F_SilkS, p.SHAPE_T_RECT, xy(-1.725, 3.25), xy(1.725, -3.25), 0.15)
add_shape(pcb, p.F_SilkS, p.SHAPE_T_CIRCLE, xy(-3.65, 3.9), xy(-3.44, 3.9), 0.16)

plane_layers = {"inner1": p.In1_Cu, "inner2": p.In2_Cu, "bottom": p.B_Cu}
for plane in design["planes"]:
    zone = p.ZONE(pcb)
    zone.SetLayer(plane_layers[plane["layer"]])
    zone.SetNet(nets[plane["net"]])
    zone.SetLocalClearance(mm(0.2))
    zone.SetMinThickness(mm(0.15))
    zone.SetPadConnection(p.ZONE_CONNECTION_THERMAL)
    zone.SetThermalReliefGap(mm(0.22))
    zone.SetThermalReliefSpokeWidth(mm(0.28))
    outline = zone.Outline()
    outline.NewOutline()
    left, right = -width / 2 + 0.4, width / 2 - 0.4
    bottom, top = -height / 2 + 0.4, height / 2 - 0.4
    for x, y in [(left, top), (right, top), (right, bottom), (left, bottom)]:
        outline.Append(xy(x, y))
    pcb.Add(zone)

settings = pcb.GetDesignSettings()
settings.SetBoardThickness(mm(design["board"]["thickness"]))
settings.m_MinClearance = mm(0.15)
settings.m_CopperEdgeClearance = mm(0.30)
settings.m_HoleClearance = mm(0.20)
settings.m_SolderMaskExpansion = mm(0.025)
settings.m_SolderMaskMinWidth = mm(0.10)
settings.m_TrackMinWidth = mm(0.20)
settings.m_TentViasFront = True
settings.m_TentViasBack = True
settings.m_ViasMinSize = mm(0.60)
settings.m_ViasMinAnnularWidth = mm(0.125)
settings.m_MinThroughDrill = mm(0.30)

board_path = str(BUILD / "audio-dac.kicad_pcb")
p.SaveBoard(board_path, pcb)
loaded = p.LoadBoard(board_path)
loaded.BuildConnectivity()
filler = p.ZONE_FILLER(loaded)
filler.Fill(loaded.Zones())
p.SaveBoard(board_path, loaded)

# Keep the JLCPCB BOM and placement rows aligned for the intended top-side SMT run.
smt = [part for part in design["parts"] if not part["ref"].startswith("J")]
bom_rows = defaultdict(list)
for part in smt:
    bom_rows[(part["value"], part["code"])].append(part["ref"])
with (BUILD / "JLCPCB-BOM.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["Comment", "Designator", "Footprint", "LCSC Part #"])
    for (value, code), designators in bom_rows.items():
        writer.writerow([value, ",".join(designators), design["catalog"][code]["package"], code])
with (BUILD / "JLCPCB-CPL.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["Designator", "Mid X", "Mid Y", "Layer", "Rotation"])
    for part in smt:
        footprint = components[part["ref"]]
        x, y = footprint["footprint_origin"]["x"], footprint["footprint_origin"]["y"]
        writer.writerow([part["ref"], f"{21 + x:.4f}mm", f"{-14 + y:.4f}mm", "Top",
                         part["rotation"] % 360])
