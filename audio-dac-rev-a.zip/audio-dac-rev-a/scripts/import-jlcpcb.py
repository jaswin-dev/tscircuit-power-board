"""Refresh the local footprints from the EasyEDA catalog keyed by JLCPCB part ID."""
import json
import sys
from pathlib import Path
from urllib.request import urlopen

PARTS = {
    "C107671": ("PCM5102APWR", "TSSOP-20"),
    "C14663": ("CC0603KRX7R9BB104", "0603"),
    "C1713": ("CL21A106KOQNNNE", "0805"),
    "C28234": ("CL21B225KOFNNNE", "0805"),
    "C114669": ("RC0603FR-07470RL", "0603"),
    "C107043": ("CC0603JRNPO9BN222", "0603"),
    "C50951": ("2.54mm 1*5P Straight Pin Header", "TH 1x5 2.54 mm"),
    "C49257": ("2.54-1*3PPin", "TH 1x3 2.54 mm"),
}


def mm(value):
    return round(float(value) * 0.254, 5)


def footprint(code, manufacturer_part_number, package_name):
    if len(sys.argv) == 2:
        data = json.loads((Path(sys.argv[1]) / f"{code}.json").read_text())
    else:
        url = f"https://easyeda.com/api/products/{code}/components"
        with urlopen(url, timeout=25) as response:
            data = json.load(response)
    part = data["result"]
    assert part["lcsc"]["number"] == code
    package = part["packageDetail"]["dataStr"]
    ox, oy = float(package["head"]["x"]), float(package["head"]["y"])
    pads = []
    for primitive in package["shape"]:
        fields = primitive.split("~")
        if fields[0] != "PAD":
            continue
        _, shape, x, y, w, h, layer, _, number, radius, _, angle, *_ = fields
        assert float(angle) == 0 and layer in ("1", "11")
        assert shape in ("RECT", "OVAL", "ELLIPSE")
        pads.append({
            "pin": int(number),
            "x": mm(float(x) - ox),
            "y": mm(oy - float(y)),
            "width": mm(w),
            "height": mm(h),
            "shape": {"RECT": "rect", "OVAL": "oval", "ELLIPSE": "circle"}[shape],
            "drill": mm(2 * float(radius)),
        })
    pads.sort(key=lambda pad: pad["pin"])
    assert [pad["pin"] for pad in pads] == list(range(1, len(pads) + 1))
    return {
        "mpn": manufacturer_part_number,
        "package": package_name,
        "catalogFootprint": part["packageDetail"]["title"],
        "pads": pads,
    }


target = Path(__file__).resolve().parents[1] / "src" / "jlcpcb-parts.json"
target.write_text(json.dumps({
    code: footprint(code, mpn, package) for code, (mpn, package) in PARTS.items()
}, indent=2) + "\n")
