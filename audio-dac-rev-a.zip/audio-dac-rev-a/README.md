# PCM5102A Stereo DAC · Rev A

A four-layer, 42 × 28 mm I²S-to-stereo-line-output board designed in tscircuit React. It takes regulated 3.3 V power and 3.3 V I²S signals. The TX device supplies BCK, LRCK, and DIN. The DAC uses its internal bit-clock PLL with SCK tied low. At 48 kHz, set the source to standard I²S with two 32-bit slots for a 3.072 MHz BCK.

The TI PCM5102APWR DAC drives two 470 Ω / 2.2 nF output filters. Nominal full-scale output at the DAC is 2.1 V RMS. Use an amplifier, powered speaker, or audio interface with a high-impedance line input. The assembled board is a prototype design and its audio performance remains to be measured.

## Connections

Pin 1 has a square pad on each 2.54 mm header. The table is in pin-number order.

| Header | Pin | Signal | Connection |
| --- | --- | --- | --- |
| J1 | 1 | 3V3 | Regulated 3.3 V supply |
| J1 | 2 | GND | Supply and I²S source ground |
| J1 | 3 | WS / LRCK | I²S word select |
| J1 | 4 | DIN | I²S serial data from the host |
| J1 | 5 | BCK | I²S bit clock |
| J2 | 1 | L | Left line output |
| J2 | 2 | GND | Analog return |
| J2 | 3 | R | Right line output |

## Fabrication and assembly

Use the files in `manufacturing/`.

1. Upload `JLCPCB-Gerbers.zip` for a four-layer, 1.6 mm FR-4 board with standard 1 oz outer copper. The board has a top signal layer, a layer-2 ground plane, a layer-3 3.3 V plane, and a bottom ground plane. All four mounting holes are 3.2 mm non-plated.
2. For top-side SMT assembly, upload `JLCPCB-BOM.csv` and `JLCPCB-CPL.csv`. Confirm part availability and match the placement preview to the square pad or pin-1 dot orientation on U1. J1 and J2 are through-hole headers intended for hand soldering.
3. Before applying audio, check the board for a short at J1, verify the regulated supply, and confirm the DAC's VNEG and LDOO nodes are approximately −3.3 V and 1.8 V under normal operation. Use a 48 kHz stereo test signal with different tones on the two channels to check channel mapping and output.

| References | Value / function | Manufacturer part | JLCPCB |
| --- | --- | --- | --- |
| U1 | Stereo DAC, TSSOP-20 | PCM5102APWR | [C107671](https://jlcpcb.com/partdetail/C107671) |
| C1, C5, C7, C9 | 100 nF, 50 V, X7R | CC0603KRX7R9BB104 | [C14663](https://jlcpcb.com/partdetail/C14663) |
| C2, C6, C8 | 10 µF, 16 V, X5R | CL21A106KOQNNNE | [C1713](https://jlcpcb.com/partdetail/C1713) |
| C3, C4 | 2.2 µF, 16 V, X7R | CL21B225KOFNNNE | [C28234](https://jlcpcb.com/partdetail/C28234) |
| C10, C11 | 2.2 nF, 50 V, C0G | CC0603JRNPO9BN222 | [C107043](https://jlcpcb.com/partdetail/C107043) |
| R1, R2 | 470 Ω, 1% | RC0603FR-07470RL | [C114669](https://jlcpcb.com/partdetail/C114669) |
| J1 | 1×5 through-hole straight header | 2.54mm 1*5P Straight Pin Header | [C50951](https://jlcpcb.com/partdetail/C50951) |
| J2 | 1×3 through-hole straight header | 2.54-1*3PPin | [C49257](https://jlcpcb.com/partdetail/C49257) |

## Source and verification

- `src/audio-dac.circuit.tsx` instantiates the parts and manual PCB traces.
- `src/jlcpcb-parts.json` contains the copper-pad and plated-hole geometries imported from the EasyEDA catalog using the JLCPCB part IDs. `python3 scripts/import-jlcpcb.py` refreshes the cached geometries.
- `src/design.ts` contains the circuit nets, component placement, and board markings. `src/routing.ts` contains the top-layer trace geometry, vias, and plane definitions.
- `manufacturing/kicad/` contains the filled PCB and local footprint library. The editable tscircuit project is the circuit source. KiCad handles zone fill, DRC, and Gerber plotting.
- `manufacturing/drc.txt` is the KiCad 9 report. It includes clearance, connectivity, and footprint checks.

To regenerate, use Node.js 22.12 or newer, KiCad 9 with its Python `pcbnew` module, and `zip`.

```sh
npm ci
npm run build
npm run export
```

`npm run build` emits Circuit JSON and SVGs under `build/`. `npm run export` repeats the build, checks the filled PCB, and generates fabrication files and a 3D render. Set `KICAD_PYTHON` to the Python executable that can import `pcbnew` if it differs from `/usr/bin/python3`.

Design reference [TI PCM5102A datasheet, Figure 33 and Table 11](https://www.ti.com/lit/ds/symlink/pcm5102a.pdf). The package models are from the [KiCad 3D library](https://github.com/KiCad/kicad-packages3D) and are covered by the license included with the models.
