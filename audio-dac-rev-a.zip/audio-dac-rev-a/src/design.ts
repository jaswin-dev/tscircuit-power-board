import catalog from "./jlcpcb-parts.json" with { type: "json" }

export type PartCode = keyof typeof catalog
export type Net = "GND" | "V3V3" | "CAPP" | "CAPM" | "VNEG" | "LDOO" |
  "BCK" | "DIN" | "LRCK" | "DAC_L" | "DAC_R" | "LINE_L" | "LINE_R"
export type Point = readonly [number, number]
type Part = {
  ref: string
  code: PartCode
  value: string
  at: Point
  rotation: number
  sch: Point
  pins: readonly Net[]
}

export const board = { width: 42, height: 28, thickness: 1.6, layers: 4 } as const
export const mountHoles = [[-17.5, 10.5], [17.5, 10.5], [-17.5, -10.5], [17.5, -10.5]] as const
export const dacPins = [
  "CPVDD", "CAPP", "CPGND", "CAPM", "VNEG", "OUTL", "OUTR", "AVDD", "AGND", "DEMP",
  "FLT", "SCK", "BCK", "DIN", "LRCK", "FMT", "XSMT", "LDOO", "DGND", "DVDD",
] as const

export const parts: readonly Part[] = [
  { ref: "U1", code: "C107671", value: "PCM5102APWR", at: [0, 0], rotation: -90, sch: [0, 1],
    pins: ["V3V3", "CAPP", "GND", "CAPM", "VNEG", "DAC_L", "DAC_R", "V3V3", "GND", "GND",
      "GND", "GND", "BCK", "DIN", "LRCK", "GND", "V3V3", "LDOO", "GND", "V3V3"] },
  { ref: "J1", code: "C50951", value: "I2S / 3V3", at: [16, 0], rotation: -90, sch: [-10, 4],
    pins: ["V3V3", "GND", "LRCK", "DIN", "BCK"] },
  { ref: "J2", code: "C49257", value: "STEREO LINE", at: [-16, -2.54], rotation: -90, sch: [10, 4],
    pins: ["LINE_L", "GND", "LINE_R"] },
  { ref: "C1", code: "C14663", value: "100nF", at: [-5.3, 4.9], rotation: 0, sch: [-11, -3],
    pins: ["GND", "V3V3"] },
  { ref: "C2", code: "C1713", value: "10uF", at: [-5.6, 6.8], rotation: 0, sch: [-7, -3],
    pins: ["GND", "V3V3"] },
  { ref: "C3", code: "C28234", value: "2.2uF", at: [-5.75, 2.35], rotation: 90, sch: [-9, 0],
    pins: ["CAPM", "CAPP"] },
  { ref: "C4", code: "C28234", value: "2.2uF", at: [-8.65, 0.12], rotation: 0, sch: [-3.5, -3],
    pins: ["GND", "VNEG"] },
  { ref: "C5", code: "C14663", value: "100nF", at: [-4.8, -5.8], rotation: -90, sch: [-11, -6],
    pins: ["V3V3", "GND"] },
  { ref: "C6", code: "C1713", value: "10uF", at: [-7.3, -6.7], rotation: -90, sch: [-7, -6],
    pins: ["V3V3", "GND"] },
  { ref: "C7", code: "C14663", value: "100nF", at: [5.1, 4.5], rotation: 0, sch: [-3, -6],
    pins: ["V3V3", "GND"] },
  { ref: "C8", code: "C1713", value: "10uF", at: [8.45, 4.5], rotation: 0, sch: [1, -6],
    pins: ["V3V3", "GND"] },
  { ref: "C9", code: "C14663", value: "100nF", at: [5.4, 1.9], rotation: 0, sch: [1, -3],
    pins: ["LDOO", "GND"] },
  { ref: "C10", code: "C107043", value: "2.2nF", at: [-12, -0.8], rotation: 90, sch: [9, 0],
    pins: ["LINE_L", "GND"] },
  { ref: "C11", code: "C107043", value: "2.2nF", at: [-12, -4.4], rotation: -90, sch: [9, -3],
    pins: ["LINE_R", "GND"] },
  { ref: "R1", code: "C114669", value: "470", at: [-8.9, -1.5], rotation: 0, sch: [5, 0],
    pins: ["LINE_L", "DAC_L"] },
  { ref: "R2", code: "C114669", value: "470", at: [-8.9, -3.7], rotation: 0, sch: [5, -3],
    pins: ["LINE_R", "DAC_R"] },
]

export const silkscreen: ReadonlyArray<{ text: string; at: Point; size: number; layer?: "top" | "bottom" }> = [
  { text: "STEREO DAC", at: [0, 10.2], size: 1.55 },
  { text: "PCM5102A  /  REV A", at: [0, 8.1], size: 0.9 },
  { text: "LINE OUT", at: [-14.6, 3.1], size: 1.0 },
  { text: "L", at: [-18.6, 0], size: 0.95 },
  { text: "G", at: [-18.6, -2.54], size: 0.95 },
  { text: "R", at: [-18.6, -5.08], size: 0.95 },
  { text: "I2S IN", at: [14.5, 7.5], size: 1.0 },
  { text: "3V3", at: [18.85, 5.08], size: 0.82 },
  { text: "GND", at: [18.85, 2.54], size: 0.82 },
  { text: "WS", at: [18.85, 0], size: 0.82 },
  { text: "DIN", at: [18.85, -2.54], size: 0.82 },
  { text: "BCK", at: [18.85, -5.08], size: 0.82 },
  { text: "3.3V POWER & LOGIC", at: [8, -10.1], size: 0.88 },
  { text: "STEREO DAC / REV A", at: [0, 1.2], size: 1.25, layer: "bottom" },
  { text: "USE A HIGH-IMPEDANCE LINE INPUT", at: [0, -1.2], size: 0.9, layer: "bottom" },
]
