import { Fragment } from "react"
import catalog from "./jlcpcb-parts.json" with { type: "json" }
import { board, dacPins, mountHoles, parts, silkscreen, type PartCode } from "./design.js"
import { routes, viaDiameter, viaDrill } from "./routing.js"

function CatalogFootprint({ code }: { code: PartCode }) {
  return <footprint>
    {catalog[code].pads.map((pad) => {
      const coords = { pcbX: pad.x, pcbY: pad.y, portHints: [`pin${pad.pin}`] }
      if (pad.drill && pad.shape === "rect") {
        return <Fragment key={pad.pin}><platedhole {...coords} shape="circular_hole_with_rect_pad"
          holeDiameter={pad.drill} rectPadWidth={pad.width} rectPadHeight={pad.height} /></Fragment>
      }
      if (pad.drill) {
        return <Fragment key={pad.pin}><platedhole {...coords} shape="circle"
          holeDiameter={pad.drill} outerDiameter={pad.width} /></Fragment>
      }
      const size = { width: pad.width, height: pad.height }
      if (pad.shape === "oval") {
        return <Fragment key={pad.pin}><smtpad {...coords} {...size} shape="pill"
          layer="top" radius={Math.min(pad.width, pad.height) / 2} /></Fragment>
      }
      return <Fragment key={pad.pin}><smtpad {...coords} {...size} shape="rect" layer="top" /></Fragment>
    })}
  </footprint>
}

function BoardPart({ part }: { part: typeof parts[number] }) {
  const props = {
    name: part.ref,
    manufacturerPartNumber: catalog[part.code].mpn,
    supplierPartNumbers: { jlcpcb: [part.code], lcsc: [part.code] },
    pcbX: part.at[0],
    pcbY: part.at[1],
    pcbRotation: part.rotation,
    schX: part.sch[0],
    schY: part.sch[1],
    footprint: <CatalogFootprint code={part.code} />,
  }
  if (part.ref === "U1") {
    return <chip {...props}
      schWidth={3.35} schPinSpacing={0.35}
      pinLabels={Object.fromEntries(dacPins.map((label, index) => [`pin${index + 1}`, label]))}
      schPinArrangement={{
        leftSide: { direction: "top-to-bottom", pins: ["BCK", "DIN", "LRCK", "SCK", "FMT", "DEMP", "FLT", "XSMT", "CAPP", "CAPM"] },
        rightSide: { direction: "top-to-bottom", pins: ["OUTL", "OUTR", "AVDD", "DVDD", "CPVDD", "LDOO", "VNEG", "AGND", "DGND", "CPGND"] },
      }} />
  }
  if (part.ref.startsWith("J")) {
    const labels = part.ref === "J1" ? ["3V3", "GND", "WS", "DIN", "BCK"] : ["L", "GND", "R"]
    return <pinheader {...props} pinCount={labels.length} pinLabels={labels}
      pitch={2.54} schFacingDirection={part.ref === "J1" ? "right" : "left"} />
  }
  if (part.ref.startsWith("R")) return <resistor {...props} resistance={part.value} />
  return <capacitor {...props} capacitance={part.value} />
}

export default function AudioDac() {
  return <board width={board.width} height={board.height} layers={board.layers}
    thickness={board.thickness} material="fr4" routingDisabled minTraceWidth={0.2}
    minTraceToPadEdgeClearance={0.15} minViaHoleDiameter={viaDrill} minViaPadDiameter={viaDiameter}>
    {parts.map((part) => <BoardPart key={part.ref} part={part} />)}
    {[...new Set(parts.flatMap((part) => part.pins))].map((net) => <Fragment key={net}><net name={net} /></Fragment>)}
    {parts.flatMap((part) => part.pins.map((net, index) =>
      <Fragment key={`${part.ref}-${index}`}><trace from={`.${part.ref} > .pin${index + 1}`} to={`net.${net}`} /></Fragment>
    ))}
    {routes.map((route, index) => {
      const [x, y] = route.points.at(-1)!
      const source = { source_trace_id: `manual_${index}` }
      return <Fragment key={index}><pcbtrace {...source} route={[
        ...route.points.map(([px, py]) => ({
          route_type: "wire" as const, x: px, y: py, width: route.width, layer: "top" as const,
        })),
        ...(route.via ? [{
          route_type: "via" as const, x, y, from_layer: "top" as const, to_layer: "bottom" as const,
          hole_diameter: viaDrill, outer_diameter: viaDiameter,
          tented_on_top: true, tented_on_bottom: true,
        }] : []),
      ]} /></Fragment>
    })}
    {mountHoles.map(([x, y]) => <Fragment key={`${x},${y}`}><hole pcbX={x} pcbY={y} diameter={3.2} /></Fragment>)}
    {silkscreen.map(({ text, at: [x, y], size, layer }) =>
      <Fragment key={text + x + y}><silkscreentext text={text} pcbX={x} pcbY={y} fontSize={size} layer={layer ?? "top"} /></Fragment>
    )}
    <silkscreenrect pcbX={0} pcbY={0} width={3.45} height={6.5} strokeWidth={0.15} layer="top" />
    <silkscreencircle pcbX={-3.65} pcbY={3.9} radius={0.21} strokeWidth={0.16} layer="top" />
  </board>
}
