import catalog from "./jlcpcb-parts.json" with { type: "json" }
import { parts, type Net, type Point } from "./design.js"

export const viaDiameter = 0.60
export const viaDrill = 0.30
type Endpoint = Point | `${string}.${number}`
export type Route = { net: Net; width: number; points: Point[]; via: boolean }

export function padPosition(endpoint: string): Point {
  const [ref, number] = endpoint.split(".")
  const part = parts.find((candidate) => candidate.ref === ref)
  if (!part) throw new Error(`Unknown component ${ref}`)
  const pad = catalog[part.code].pads.find((candidate) => candidate.pin === Number(number))
  if (!pad) throw new Error(`Unknown pad ${endpoint}`)
  const angle = part.rotation * Math.PI / 180
  const x = part.at[0] + pad.x * Math.cos(angle) - pad.y * Math.sin(angle)
  const y = part.at[1] + pad.x * Math.sin(angle) + pad.y * Math.cos(angle)
  return [Number(x.toFixed(5)), Number(y.toFixed(5))]
}

function route(net: Net, width: number, via: boolean, ...endpoints: Endpoint[]): Route {
  return {
    net, width, via,
    points: endpoints.map((endpoint) => {
      if (typeof endpoint !== "string") return endpoint
      const [ref, number] = endpoint.split(".")
      const part = parts.find((candidate) => candidate.ref === ref)
      if (part?.pins[Number(number) - 1] !== net) throw new Error(`Net mismatch at ${endpoint}`)
      return padPosition(endpoint)
    }),
  }
}

const signal = (net: Net, ...points: Endpoint[]) => route(net, 0.22, false, ...points)
const power = (...points: Endpoint[]) => route("V3V3", 0.27, false, ...points)
const plane = (net: "GND" | "V3V3", ...points: Endpoint[]) =>
  route(net, net === "GND" ? 0.22 : 0.27, true, ...points)

export const routes = [
  // Charge pump and bypass capacitors next to the left-hand DAC pins.
  power("U1.1", [-3.95, 2.92506], [-4.6, 3.57512], "C1.2"),
  power("C1.2", "C2.2"),
  plane("V3V3", "C2.2", [-4.60, 8.0]),
  plane("GND", "C1.1", [-7.1, 4.9]),
  plane("GND", "C2.1", [-6.6, 8.0]),
  signal("CAPP", "U1.2", [-4.05, 2.27508], [-5.1249, 3.35], "C3.2"),
  plane("GND", "U1.3", [-4.15, 1.62509]),
  signal("CAPM", "U1.4", [-4.6, 0.97511], "C3.1"),
  signal("VNEG", "U1.5", [-5.95, 0.32512], "C4.2"),
  plane("GND", "C4.1", [-10.75, 0.12]),

  // Analog outputs and the 470-ohm / 2.2-nF filters.
  signal("DAC_L", "U1.6", [-5.5, -0.32512], [-6.67488, -1.5], "R1.2"),
  signal("DAC_R", "U1.7", [-4.65, -0.97511], [-7.37489, -3.7], "R2.2"),
  signal("LINE_L", "R1.1", [-13.6, -1.5], [-15.1, 0], "J2.1"),
  signal("LINE_L", [-12, -1.5], "C10.1"),
  signal("LINE_R", "R2.1", [-13.7, -3.7], [-15.08, -5.08], "J2.3"),
  signal("LINE_R", [-12, -3.7], "C11.1"),
  plane("GND", "C10.2", [-12, 0.9]),
  plane("GND", "C11.2", [-12, -6.0]),

  // Analog rail bypass and mode straps.
  power("U1.8", [-3.76, -1.62509], [-4.8, -2.66518], "C5.1"),
  power("C5.1", [-6.23, -5.09998], [-6.83, -5.70], "C6.1"),
  plane("V3V3", "C6.1", [-8.5, -5.70]),
  plane("GND", "C5.2", [-4.8, -7.6]),
  plane("GND", "C6.2", [-7.3, -8.8]),
  plane("GND", "U1.9", [-1.65, -2.27508]),
  plane("GND", "U1.10", [-1.05, -2.92506]),

  // Digital rail, internal regulator bypass, and mode straps.
  power("U1.20", [4.1, 2.92506], [4.39998, 3.22504], "C7.1"),
  power("C7.1", [4.39998, 5.65], [7.45, 5.65], "C8.1"),
  plane("V3V3", [4.39998, 5.65], [4.39998, 6.6]),
  plane("GND", "C7.2", [5.8, 3.48]),
  plane("GND", "C8.2", [9.45, 3.41]),
  plane("GND", "U1.19", [1.65, 2.27508]),
  signal("LDOO", "U1.18", [4.42, 1.62509], "C9.1"),
  plane("GND", "C9.2", [7.05, 1.9]),
  plane("V3V3", "U1.17", [1.05, 0.97511]),
  plane("GND", "U1.16", [1.65, 0.32512]),
  plane("GND", "U1.12", [4.12, -2.27508]),
  plane("GND", "U1.11", [4.25, -3.49]),

  // Three-wire I2S. Keep these on the side opposite the line outputs.
  signal("LRCK", "U1.15", [10.8, -0.32512], [11.12512, 0], "J1.3"),
  signal("DIN", "U1.14", [8.7, -0.97511], [10.26489, -2.54], "J1.4"),
  signal("BCK", "U1.13", [5.6, -1.62509], [9.05491, -5.08], "J1.5"),
]

export const planes = [
  { net: "GND", layer: "inner1" },
  { net: "V3V3", layer: "inner2" },
  { net: "GND", layer: "bottom" },
] as const
